from django.contrib import admin
from .models import Student, Professor, ProfessorWeeklySchedule, WeeklyScheduleChoice, Session, Appointment_Request, Door_Status

admin.site.register(Student)
admin.site.register(Professor)
admin.site.register(WeeklyScheduleChoice)
admin.site.register(ProfessorWeeklySchedule)
admin.site.register(Session)
admin.site.register(Appointment_Request)
admin.site.register(Door_Status)
