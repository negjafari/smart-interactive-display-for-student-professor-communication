from django.db import models
from django.contrib.auth.models import User


class Professor(models.Model):

    STATUS_CHOICES = [
        ('Available', 'Available'),
        ('Department Office', 'Department Office'),
        ('Class', 'Class'),
        ('Meeting', 'Meeting'),
        ('Busy', 'Busy'),
        ('Back in 1 hour', 'Back in 1 hour'),
        ('Back in 2 hours', 'Back in 2 hours'),
        ('Out of Campus', 'Out of Campus'),
    ]

    EDUCATION_CHOICES = [
        ('Instructor', 'Instructor'),
        ('Assistant Professor', 'Assistant Professor'),
        ('Associate Professor', 'Associate Professor'),
        ('Professor', 'Professor')
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    field_of_study = models.CharField(max_length=255)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Available')
    education = models.CharField(max_length=20, choices=EDUCATION_CHOICES, default='Instructor')


    def __str__(self):
        return self.name


class Student(models.Model):
    name = models.CharField(max_length=255)
    student_id = models.CharField(max_length=10)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.name
    

class Session(models.Model):
    name = models.CharField(max_length=255)
    student_id = models.CharField(max_length=10)
    email = models.EmailField(max_length=100)
    is_active = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return self.name

class WeeklyScheduleChoice(models.Model):
    DAY_CHOICES = [
        ('Wednesday', 'Wednesday'),
        ('Tuesday', 'Tuesday'),
        ('Monday', 'Monday'),
        ('Sunday', 'Sunday'),
        ('Saturday', 'Saturday')
    ]
    PERIOD_CHOICES = [
        (1, 1),
        (2, 2),
        (3, 3),
        (4, 4),
        (5, 5),
    ]

    day = models.CharField(max_length=20, choices=DAY_CHOICES)
    period = models.IntegerField(choices=PERIOD_CHOICES)
    description = models.CharField(max_length=50)
    is_available = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.description} - {self.day} - {self.period}"


class ProfessorWeeklySchedule(models.Model):
    professor = models.ForeignKey(Professor, on_delete=models.CASCADE)
    choice = models.ForeignKey(WeeklyScheduleChoice, on_delete=models.CASCADE, null=True, blank=True)


    def __str__(self):
        return f"{self.professor.name} - {self.choice}"
    

class Appointment_Request(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    ]

    professor = models.ForeignKey(Professor, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    request_day = models.IntegerField()  
    request_period = models.IntegerField()  
    student_message = models.TextField(blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Pending')

    def __str__(self):
        return f"Request from {self.student.name} to {self.professor.name}"


class Door_Status(models.Model):
    professor = models.ForeignKey(Professor, on_delete=models.CASCADE)
    is_door_open = models.BooleanField(default=False)

    def __str__(self):
        if self.is_door_open:
            return "Door Is Open"
        else:
            return "Door Is Close"




