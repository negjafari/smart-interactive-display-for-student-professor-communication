from django.urls import path
from . import views

urlpatterns = [
    path('send-email/', views.send_email),
    path('login/', views.login_page, name='professor_login'),
    path('booking/', views.booking_page, name='booking'),
    path('', views.main_page, name='home'),
    path('professor/', views.professor_page, name='professor'),

    path('api/data/', views.DataAPIView.as_view(), name='data-api'),
    path('api/data/<str:pname>', views.DataAPIView.as_view(), name='status'),

    path('api/door-status/', views.DoorStatusAPIView.as_view(), name='check-door'),
    path('api/door-status/<str:pname>', views.DoorStatusAPIView.as_view(), name='door-status'),

    path('check/', views.check_condition, name='check_condition'),

]